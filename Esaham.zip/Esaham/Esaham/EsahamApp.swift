//
//  EsahamApp.swift
//  Esaham
//
//  Created by AlAnoud on 23/01/2024.
//

import SwiftUI

@main
struct EsahamApp: App {
    var body: some Scene {
        
        
        
        WindowGroup {
            ContentView()
        }
    }
}


