import SwiftUI
import Combine


import SwiftUI

//---------------------------------------------------- Community  View --------------------------------------------------
struct CommunityView: View {
    var body: some View {
        Text("")
    }
}

//-------------------------------------------------------- Plant  View --------------------------------------------------
struct MyPlantView: View {
    var body: some View {
        Text("")
    }
}
//-------------------------------------------------------- Tasks  View --------------------------------------------------
struct TasksView: View {
    var body: some View {
        Text("")
    }
}
//-------------------------------------------------------- Team  View --------------------------------------------------
struct TeamView: View {
        var body: some View {
            NavigationView {
                
                VStack(spacing: 20) {
                    NavigationLink(destination: CreateChallengeView().background(Color("BackgroundColor")))
                    {
                        ZStack {
                            RoundedRectangle(cornerRadius: 11)
                                .fill(Color("ButtonColor"))
                                .frame(width: 328, height: 105)
                                .shadow(color:  Color("ShadowColor"), radius: 4, x: 0, y: 4)
                            
                            Text("Create Challenge")
                                .font(Font.custom("NotoSans", size: 20))
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.bottom, 40)
                    
                    NavigationLink(destination: JoinChallengeView().background(Color("BackgroundColor"))) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 11)
                                .fill(Color("ButtonColor"))
                                .frame(width: 328, height: 105)
                                .shadow(color: Color("ShadowColor"), radius: 4, x: 0, y: 4)
                            
                            Text("Join Challenge")
                                .font(Font.custom("NotoSans", size: 20))
                                .foregroundColor(.white)
                        }
                    }
                }
                
                .padding(.top, -20)
                .background(Color.white)
                
            }
        }
    }

    //------------------- Create Challenge View -----------------------
    struct CreateChallengeView: View {
            @State private var challengeName = ""
            @State private var challengeCode = ""
            @State private var randomNumber = generateRandomNumber()
            @Environment(\.dismiss) private var dismiss

            var body: some View {
                VStack(spacing: 20) {
                    Spacer()

                    VStack(alignment: .leading, spacing: 20) {
                        Text("Challenge name")
                            .font(.custom("NotoSans-Regular", size: 20))
                            .foregroundColor(Color("TextColor"))
                            .offset(y:-300)

                        TextField("Enter challenge name", text: $challengeName)
                            .frame(width: 320)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .offset(y:-300)

                        Text("Challenge Code")
                            .font(.custom("NotoSans-Regular", size: 20))
                            .foregroundColor(Color("TextColor"))
                            .offset(y:-250)

                        Rectangle()
                            .fill(Color.white)
                            .frame(width: 328, height: 80)
                            .overlay(
                                RandomView(randomNumber: $randomNumber)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                            )
                            .offset(y:-250)
                    }

                    NavigationLink(destination: ChooseMonthView().background(Color("BackgroundColor"))) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 11)
                                .fill(Color("ButtonColor"))
                                .frame(width: 302, height: 53)
                                .shadow(color: Color("ShadowColor"), radius: 4, x: 0, y: 4)

                            Text("Create")
                                .font(Font.custom("NotoSans", size: 20))
                                .foregroundColor(.white)
                        }
                    }
                    .offset(y:-150)
                }
                .navigationBarTitle("Create Challenge", displayMode: .inline)
                .navigationBarBackButtonHidden()
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button(action: {
                            dismiss()
                        }) {
                            Image(systemName: "chevron.backward")
                                .foregroundColor(Color("BackColor"))
                        }
                    }
                }
            }

            // Function to generate a random number in the format 000-000-000
            private static func generateRandomNumber() -> String {
                let random1 = String(format: "%03d", Int.random(in: 0...999))
                let random2 = String(format: "%03d", Int.random(in: 0...999))
                let random3 = String(format: "%03d", Int.random(in: 0...999))
                return "\(random1)-\(random2)-\(random3)"
            }
        }

        struct RandomView: View {
            @Binding var randomNumber: String
            @State private var copied = false

            var body: some View {
                HStack {
                    Text(randomNumber)
                        .font(.system(size: 36))
                        .foregroundColor(Color("TextColor"))

                    Button(action: {
                        UIPasteboard.general.string = randomNumber
                        copied = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            copied = false
                        }
                    }) {
                        Image(systemName: "doc.on.doc")
                            .font(.system(size: 24))
                            .foregroundColor(Color("PrimaryColor"))
                    }
                }
                .overlay(
                    copied ? Text("Copied!")
                        .foregroundColor(Color("PrimaryColor"))
                        //.padding(10)
                        .background(Color.white)
                        .cornerRadius(5)
                        .padding(.leading, 10)
                        : nil,
                    alignment: .topTrailing
                )
            }
        }

    //------------------- Join Challenge View -----------------------
    struct JoinChallengeView: View {
        @State public var challengeName = ""
        @State public var challengeCode = ""
        @Environment(\.dismiss) private var dismiss

        
        var body: some View {
            VStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Challenge name")
                        .font(.custom("NotoSans-Regular", size: 20))
                        .foregroundColor(Color("TextColor"))
                        .offset(y:-50)
                    
                    TextField("Enter challenge name", text: $challengeName)
                        .frame(width: 320)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .offset(y:-40)
                }
                
                VStack(alignment: .leading, spacing: 5) {
                    Text("Challenge code")
                        .font(.custom("NotoSans-Regular", size: 20))
                        .foregroundColor(Color("TextColor"))
                        .offset(y:-10)
            
                    TextField("Enter challenge Code", text: $challengeCode)
                        .offset(y:0)
                        .frame(width: 320)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                        .onChange(of: challengeCode) { newValue in
                            let filtered = newValue.filter { "0123456789-".contains($0) }
                            if filtered != newValue {
                                self.challengeCode = filtered
                            }
                            if self.challengeCode.count == 4 || self.challengeCode.count == 8 {
                                if !self.challengeCode.hasSuffix("-") {
                                    self.challengeCode.insert("-", at: self.challengeCode.index(self.challengeCode.endIndex, offsetBy: -1))
                                }
                            }
                            if self.challengeCode.count > 11 {
                                self.challengeCode = String(self.challengeCode.prefix(11))
                            }
                        }
                }
            
                
                NavigationLink(destination: WaitForChallengeView().background(Color("ButtonColor"))) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 11)
                            .fill(Color("ButtonColor"))
                            .frame(width: 302, height: 53)
                            .shadow(color: Color("ShadowColor").opacity(0.25), radius: 4, x: 0, y: 4)
                        
                        Text("Create")
                            .font(Font.custom("NotoSans", size: 20))
                            .foregroundColor(.white)
                    }
                    .padding(.top, 60)
                }
            }
            .navigationBarTitle("Join Challange", displayMode: .inline)
            .navigationBarBackButtonHidden()
            .toolbar {

                            ToolbarItem(placement: .navigationBarLeading) {

                                Button {
                                    dismiss()

                                } label: {
                                    HStack {

                                        Image(systemName: "chevron.backward")
                                            .foregroundColor(Color("BackColor"))
                                     
                                    }
                                }
                            }
                        }

        }
    }

    //------------------- Choose Month View -----------------------
    struct ChooseMonthView: View {
        let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
            
            @State public var selectedMonth: String?
            @Environment(\.dismiss) private var dismiss

            
            var body: some View {
                Text("Choose the month that track your progress in challenges")
                    .font(.custom("NotoSans-Regular", size: 12))
                    .foregroundColor(Color("ShadowColor"))
                    .offset(y:-50)
                
            
                VStack(spacing: 30) {
                    ForEach(0..<4) { row in
                        HStack(spacing: 25) {
                            ForEach(0..<3) { column in
                                let index = row * 3 + column
                                let month = months[index]
                                CircleView(month: month, isSelected: selectedMonth == month)
                                    .onTapGesture {
                                        selectedMonth = month
                                    }
                            }
                        }
                    }
                }
                .offset(y:5)
                .navigationBarTitle("Choose The Month", displayMode: .inline)
                .navigationBarBackButtonHidden()
                .toolbar {
                                ToolbarItem(placement: .navigationBarLeading) {

                                    Button {
                                        dismiss()

                                    } label: {
                                        HStack {

                                            Image(systemName: "chevron.backward")
                                                .foregroundColor(Color("BackColor"))
                                         
                                        }
                                    }
                                }
                            }

             
                NavigationLink(destination: StartChallengeView().background(Color("ButtonColor"))) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 11)
                            .fill(Color("ButtonColor"))
                            .frame(width: 302, height: 53)
                            .shadow(color: Color("ShadowColor"), radius: 4, x: 0, y: 4)
                        
                        Text("Next")
                            .font(Font.custom("NotoSans", size: 20))
                            .foregroundColor(.white)
                    }

                }
                .padding(.top, 60)
            }
        }

        struct CircleView: View {
            let month: String
            let isSelected: Bool
            
            var body: some View {
                ZStack {
                    Circle()
                        .fill(isSelected ? Color("PrimaryColor") : Color.clear)
                        .overlay(
                            Circle()
                                .stroke(Color("PrimaryColor"), lineWidth: 2)
                                .shadow(color: Color("ShadowColor"), radius: 4, x: 0, y: 2)
                        )
                        .frame(width: 87, height: 87)
                    
                    Text(month)
                        .font(.custom("NotoSans", size: 14))
                        .foregroundColor(isSelected ? Color(.white) : Color("PrimaryColor"))
                    
                }
                
            }
            
        }

    //------------------- Start Challenge View -----------------------
    struct StartChallengeView: View {
        @Environment(\.dismiss) private var dismiss
        
        var body: some View {
            Text("Start Challenge Page")
                .background(Color("BackgroundColor"))
            
            
        }
    }



    //------------------- Wait For Challenge View -----------------------
    struct WaitForChallengeView: View {
        @Environment(\.dismiss) private var dismiss
        
        var body: some View {
            Text("Wait For Challenge Page")
                .background(Color("BackgroundColor"))
        }
    }


//-------------------------------------------- Navigation Bar --------------------------------------------------
struct ContentView: View {
    // enum for Tabs, add other tabs if needed
    enum Tab {
        case community, plant, tasks, profile
    }

    @State private var selectedTab: Tab = .community

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                TabView(selection: $selectedTab) {
                    NavigationView {
                        CommunityView()
                            .navigationBarTitle("Community", displayMode: .inline)
                    }
                    .tabItem {
                        Image(systemName: "person.3")
                        Text("Community")
                    }
                    .tag(Tab.community)


                    NavigationView {
                        MyPlantView()
                            .navigationBarTitle("Plant", displayMode: .inline)
                            
                    }
                    .tabItem {
                        Image(systemName: "tree")
                        Text("Plant")
                    }
                    .tag(Tab.plant)

                    NavigationView {
                        TasksView()
                            .navigationBarTitle("Tasks", displayMode: .inline)
                    }
                    .tabItem {
                        Image(systemName: "flag")
                        Text("Tasks")
                    }
                    .tag(Tab.tasks)

                    NavigationView {
                        TeamView()
                            .navigationBarTitle("Team", displayMode: .inline)
                    }
                    .tabItem {
                        Image(systemName: "person")
                        Text("Team")
                    }
                    .tag(Tab.profile)
                }
                .edgesIgnoringSafeArea(.top)
                .frame(maxHeight: .infinity)
                .accentColor(Color("PrimaryColor"))

              
                
                Divider()
                    .padding(.top, 650.0)
               
                    
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

