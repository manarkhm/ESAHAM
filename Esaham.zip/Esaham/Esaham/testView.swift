import SwiftUI

struct TestView: View {
    @State public var challengeName = ""
    @State public var challengeCode = ""
    @Environment(\.dismiss) private var dismiss
    
    
    var body: some View {
        VStack(spacing: 20) {
            VStack(alignment: .leading, spacing: 5) {
                Text("Challenge name")
                    .font(.custom("NotoSans-Regular", size: 17))
                    .foregroundColor(Color("TextColor"))
                    .padding(.leading, 22.0)
                
                TextField("Enter challenge name", text: $challengeName)
                    .frame(width: 320)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading, 22.0)
            }
            
            VStack(alignment: .leading, spacing: 5) {
                Text("Challenge code")
                    .font(.custom("NotoSans-Regular", size: 17))
                    .foregroundColor(Color("TextColor"))
                    .padding(.leading, 22.0)
        
                TextField("Enter challenge Code", text: $challengeCode)
                    .padding()
                    .keyboardType(.numberPad)
                    .onChange(of: challengeCode) { newValue in
                        let filtered = newValue.filter { "0123456789-".contains($0) }
                        if filtered != newValue {
                            self.challengeCode = filtered
                        }
                        if self.challengeCode.count == 4 || self.challengeCode.count == 8 {
                            if !self.challengeCode.hasSuffix("-") {
                                self.challengeCode.insert("-", at: self.challengeCode.index(self.challengeCode.endIndex, offsetBy: -1))
                            }
                        }
                        if self.challengeCode.count > 12 {
                            self.challengeCode = String(self.challengeCode.prefix(12))
                        }
                    }
            }
        }
    }    
    
    
    struct TestView_Previews: PreviewProvider {
        static var previews: some View {
            TestView()
        }
    }
}
